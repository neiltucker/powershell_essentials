If (Get-Module -ListAvailable -Name SQLServer) {Write-Output "SQLServer module already installed" ; Import-Module SQLServer} Else {Install-Module -Name SQLServer -AllowClobber -Force ; Import-Module -Name SQLServer}
Import-Module -Name SQLSERVER -Force
Set-Location SQLServer:\SQL\localhost
$DBFolder = "C:\NYCTaxi\"
IF (-not(Test-Path $DBFolder)) {New-Item -ItemType Directory -Path $DBFolder}
Invoke-SQLCMD -Inputfile c:\classfiles\tools\nyctaxi_install.sql -TrustServerCertificate



